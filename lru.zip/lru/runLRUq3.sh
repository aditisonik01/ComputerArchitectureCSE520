#!/bin/sh
cd m5out
mkdir project3
cd ..
./build/ARM/gem5.opt ./configs/example/se.py --cpu-type=TimingSimpleCPU --caches --l1d_size=1kB --l1d_assoc=4 --l2_size=16kB --l2_assoc=16 --l1i_size=2kB --cacheline_size=32 --l1i_assoc=1 --l2cache --num-l2caches=1 -c ./benchmarks/dijkstra/dijkstra_small -o ./benchmarks/dijkstra/input.dat
mv m5out/stats.txt m5out/project3/config_lru_dijkstra.txt
./build/ARM/gem5.opt ./configs/example/se.py --cpu-type=TimingSimpleCPU --caches --l1d_size=1kB --l1d_assoc=4 --l2_size=16kB --l2_assoc=16 --l1i_size=2kB --cacheline_size=32 --l1i_assoc=1 --l2cache --num-l2caches=1 -c ./benchmarks/basicmath/basicmath_small
mv m5out/stats.txt m5out/project3/config_lru_basicmath.txt
./build/ARM/gem5.opt ./configs/example/se.py --cpu-type=TimingSimpleCPU --caches --l1d_size=1kB --l1d_assoc=4 --l2_size=16kB --l2_assoc=16 --l1i_size=2kB --cacheline_size=32 --l1i_assoc=1 --l2cache --num-l2caches=1 -c ./benchmarks/qsort/qsort_small -o ./benchmarks/qsort/input_small.dat
mv m5out/stats.txt m5out/project3/config_lru_qsort.txt
./build/ARM/gem5.opt ./configs/example/se.py --cpu-type=TimingSimpleCPU --caches --l1d_size=1kB --l1d_assoc=4 --l2_size=16kB --l2_assoc=16 --l1i_size=2kB --cacheline_size=32 --l1i_assoc=1 --l2cache --num-l2caches=1 -c ./benchmarks/FFT/fft -o "4 4096"
mv m5out/stats.txt m5out/project3/config_lru_fft.txt
